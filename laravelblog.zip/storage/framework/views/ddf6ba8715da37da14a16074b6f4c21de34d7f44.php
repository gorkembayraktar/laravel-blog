
<?php $__env->startSection('title','Profil Ayarları'); ?>
<?php $__env->startSection('content'); ?>


<div class="card shadow mb-4">
    <div class="card-header">
        Ayarlar
    </div>      
    <div class="card-body">
    
       
        <div class="row">
            <div class="col-sm">Adı Soyadı</div>
            <div class="col"><?php echo e(auth()->user()->name); ?></div>
        </div>
        <div class="row">
            <div class="col-sm">Email Adresi</div>
            <div class="col"><?php echo e(auth()->user()->email); ?></div>
        </div>
        <div class="form-group">
            <a href="<?php echo e(route('admin.profile.update')); ?>" class="btn btn-sm btn-success ">Güncelle</a>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/back/profile/index.blade.php ENDPATH**/ ?>