
<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            Kategoriler
        </div>
        <div class="list-group">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item <?php if(Request::segment(2) == $category->slug): ?> active disabled <?php endif; ?>">
                <a href="<?php echo e(route('kategori',$category->slug)); ?>"><?php echo e($category->name); ?></a> <span class="badge badge-info"><?php echo e($category->articleCount()); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/front/widgets/categoryWidget.blade.php ENDPATH**/ ?>