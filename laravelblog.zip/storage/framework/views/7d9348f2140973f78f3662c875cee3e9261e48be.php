
<?php $__env->startSection('title',$page->title); ?>
<?php $__env->startSection('image',$page->image); ?>
<?php $__env->startSection('content'); ?>
    

        <div class="col-lg-8 col-md-10 mx-auto">
            <?php echo e($page->content); ?>

        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/front/page.blade.php ENDPATH**/ ?>