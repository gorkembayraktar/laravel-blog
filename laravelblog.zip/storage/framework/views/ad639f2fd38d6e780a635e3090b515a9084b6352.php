
<?php $__env->startSection('title','Silinen Makaleler'); ?>
<?php $__env->startSection('content'); ?>

  

  <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold float-right text-primary"><?php echo e($articles->count()); ?> makale bulundu.</h6>
                            <a href="<?php echo e(route('admin.makaleler.index')); ?>" class="btn btn-sm btn-info">Makaleler</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                               
                                    
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Resim</th>
                                            <th>Kategori Adı</th>
                                            <th>Başlık</th>
                                            <th>İçerik</th>
                                            <th>Silinme tarih</th>
                                            <th>Aksiyon</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><img src='<?php echo e(asset($article->image)); ?>' height="50" width="50"/></td>
                                            <td><?php echo e($article->getCategory->name); ?></td>
                                            <td><?php echo e($article->title); ?></td>
                                            <td><?php echo e(substr( strip_tags($article->content),0,100) . '...'); ?></td>
                                            <td><?php echo e($article->deleted_at->diffForHumans()); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('admin.article.recover',$article->id)); ?>" class="btn btn-sm btn-primary text-light">Kurtar</a>
                                                    <a href="<?php echo e(route('admin.article.delete.force',$article->id)); ?>" class="btn btn-sm btn-danger text-light"><i class="fa fa-times"></i></a>
                                                   
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                              
                            </div>
                        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('javascript'); ?>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<script>

$(function() {

    let adres = "<?php echo e(route('admin.switch')); ?>";

    $('.toggle-event').change(function() {
       $.get(adres,{id:$(this).data('articleid'),status:$(this).prop('checked')}).then(function(data,text,xhr){
        if(xhr.status === 200){
            toastr.success('Güncellendi', 'Kayıt güncellendi.')
        }
       });
    })
  })

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/back/articles/trashed.blade.php ENDPATH**/ ?>