<?php if(count($articles) > 0): ?>
    

<h3><?php echo e(count($articles)); ?> makale bulundu.</h3>

<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<div class="post-preview">
    <a href="<?php echo e(route('single',[$article->getCategory->slug,$article->slug])); ?>">
        <h2 class="post-title">
            <?php echo e($article->title); ?>

        </h2>
        <img src="<?php echo e($article->image); ?>" alt="">
        <h3 class="post-subtitle">
            <?php echo e(Str::limit($article->content,100)); ?>

            </h3>
        </a>
        <p class="post-meta">Kategori:
            <a href="#"><?php echo e($article->getCategory->name); ?></a>
            <span class="float-right"><?php echo e($article->created_at->diffForHumans()); ?></span></p>
        </div>
        <?php if(!$loop->last): ?>
    <hr>
    <?php endif; ?>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="text-center">

        <?php echo e($articles->links()); ?>

    </div>
<?php else: ?>

<h1 class="alert alert-danger">Makale bulunamadı!</h1>

<?php endif; ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/front/widgets/postsWidget.blade.php ENDPATH**/ ?>