
<?php $__env->startSection('title',$article->title.' makalesini güncelle'); ?>
<?php $__env->startSection('content'); ?>

  

  <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold float-right text-primary"></h6>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo e(route('admin.makaleler.update',$article->id)); ?>" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Makale Başlığı</label>
                                    <input type="text" name="title" value="<?php echo e($article->title); ?>" class="form-control" id="" />
                                </div>
                                <div class="form-group">
                                    <label for="">Makale Kategori</label>
                                    <select name="category" class="form-control" id="">
                                        
                                        <option value="">Seçim yapınız</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if($category->id == $article->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Makale Fotoğrafı</label>
                                    <?php if(!empty($article->image)): ?>
                                    <img src="<?php echo e(asset($article->image)); ?>" height="100" width="100" />
                                    <?php endif; ?>
                                    <input type="file" name="image" class="form-control" />
                                </div>

                                <div class="form-group">
                                    <label for="">Makale İçeriği</label>
                                    <textarea name="content" class="form-control" id="summernote" cols="30" rows="50"><?php echo e($article->content); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">Makale oluştur</button>
                                </div>

                            </form>
                        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script>
$(document).ready(function() {
  $('#summernote').summernote({
        'height':300
  });
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/back/articles/update.blade.php ENDPATH**/ ?>