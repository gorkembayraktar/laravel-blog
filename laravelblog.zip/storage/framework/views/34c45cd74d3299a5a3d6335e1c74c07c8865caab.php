
<?php $__env->startSection('title','Profil Ayarları'); ?>
<?php $__env->startSection('content'); ?>


<div class="card shadow mb-4">
    <div class="card-header">
        Ayarlar
    </div>      
    <div class="card-body">
            <?php if(session('update')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

         
            <?php if(!session('passwordErrors')): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
  

            
            <form method="post" action="<?php echo e(route('admin.profile.update.post')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Adı Soyadı</label>
                            <input type="text" name="name" reqired class="form-control" value="<?php echo e(auth()->user()->name); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="text-success">Email Adresi</label>
                            <input type="text" name="email" reqired class="form-control" value="<?php echo e(auth()->user()->email); ?>">
                        </div>
                    </div>
                </div>

              

             
                <div class="form-group">
                    <button type="submit" class="btn btn-sm btn-success ">Güncelle</button>
                </div>


            </form>
        
    </div>
    
</div>

<div class="card shadow mb-4">
    <div class="card-header">
        Şifre Değiştir
    </div>      
    <div class="card-body">

            <?php if(session('passwordChange')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            
            <?php if(session('passerror')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('passerror')); ?>

            </div>
            <?php endif; ?>


            <?php if(session('passwordErrors')): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
       
    
            
            <form method="post" action="<?php echo e(route('admin.profile.update.password')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Mevcut Şifre</label>
                            <input type="password"  name="oldpw" reqired class="form-control" >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Şifre</label>
                            <input type="password" name="password" reqired class="form-control" >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Şifre Kontrol</label>
                            <input type="password" name="password_confirmation" reqired class="form-control" >
                        </div>
                    </div>
                </div>


               
                <div class="form-group">
                    <button type="submit" class="btn btn-sm btn-success ">Şifre Güncelle</button>
                </div>


            </form>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/back/profile/update.blade.php ENDPATH**/ ?>