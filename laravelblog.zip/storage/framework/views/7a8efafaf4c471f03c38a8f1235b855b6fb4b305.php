</div>
</div>

<hr>

<!-- Footer -->
<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <ul class="list-inline text-center">

          <?php
          $socials = ['facebook','twitter','github','youtube','instagram'];
          ?>

          <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($config->$social!=null): ?>

          <li class="list-inline-item">
            <a href="<?php echo e($config->$social); ?>" target="_blank">
              <span class="fa-stack fa-lg">
                <i class="fas fa-circle fa-stack-2x"></i>
                <i class="fab fa-<?php echo e($social); ?> fa-stack-1x fa-inverse"></i>
              </span>
            </a>
          </li>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </ul>
        <p class="copyright text-muted">Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e($config->title); ?> </p>
      </div>
    </div>
  </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('front')); ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo e(asset('front')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Custom scripts for this template -->
<script src="<?php echo e(asset('front')); ?>/js/clean-blog.min.js"></script>

</body>

</html>
<?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>