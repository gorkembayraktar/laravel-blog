
<?php $__env->startSection('title','Ayarlar'); ?>
<?php $__env->startSection('content'); ?>

  

<div class="card shadow mb-4">
        <div class="card-header">
            Ayarlar
        </div>      
        <div class="card-body">
        
                
                <form method="post" action="<?php echo e(route('admin.config.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Site Başlığı</label>
                                <input type="text" name="title" reqired class="form-control" value="<?php echo e($config->title); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="text-success">Site Aktiflik Durumu</label>
                                <select class="form-control" name="active">
                                    <option <?php if($config->active == 1): ?> selected <?php endif; ?> value="1">Açık</option>
                                    <option <?php if($config->active == 0): ?> selected <?php endif; ?> value="0">Kapalı</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Logo</label>
                                <input type="file" name="logo"  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Favicon</label>
                                <input type="file" name="favicon" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Facebook</label>
                                <input type="text" name="facebook" class="form-control"  value = "<?php echo e($config->facebook); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>İnstagram</label>
                                <input type="text" name="instagram" class="form-control"  value = "<?php echo e($config->instagram); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Github</label>
                                <input type="text" name="github" class="form-control" value = "<?php echo e($config->github); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Youtube</label>
                                <input type="text" name="youtube" class="form-control"  value = "<?php echo e($config->youtube); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-sm btn-success ">Güncelle</button>
                    </div>


                </form>
            
        </div>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/back/config/index.blade.php ENDPATH**/ ?>