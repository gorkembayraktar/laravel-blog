
<?php $__env->startSection('title','İletişim'); ?>
<?php $__env->startSection('image',asset('front/img/home-bg.jpg')); ?>
<?php $__env->startSection('content'); ?>




      <div class="col-lg-8 col-md-10 mx-auto">

        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
      <form name="sentMessage" id="contactForm" method="POST" action="<?php echo e(route('contact.post')); ?>" novalidate>
        <?php echo csrf_field(); ?>  
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Ad soyad</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Adı Soyadı" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Email Adresi</label>
              <input type="email" name="email" value="<?php echo e(old('email')); ?>"  class="form-control" placeholder="Email Adresi" id="email" required data-validation-required-message="Please enter your email address.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group col-xs-12 floating-label-form-group controls">
              <label>Konu</label>
              <select class="form-control" name="topic" id="">
                  <option value="Bilgi" <?php if(old('topic') == 'Bilgi'): ?> selected <?php endif; ?>>Bilgi</option>
                  <option value="Destek" <?php if(old('topic') == 'Destek'): ?> selected <?php endif; ?>>Destek</option>
                  <option value="Genel" <?php if(old('topic') == 'Genel'): ?> selected <?php endif; ?>>Genel</option>
              </select>
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Mesaj</label>
              <textarea name="message" rows="5" class="form-control" placeholder="Mesaj" id="message" required data-validation-required-message="Please enter a message."><?php echo e(old('message')); ?></textarea>
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <br>
          <div id="success"></div>
          <button type="submit" class="btn btn-primary" id="sendMessageButton">Send</button>
        </form>
      </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GÖRKEM\Desktop\laravel\first\resources\views/front/contact.blade.php ENDPATH**/ ?>