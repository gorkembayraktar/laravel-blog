<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class App extends Controller
{
    //
    public function index(){
        echo 'anasayfa';
    }
    public function hakkimizda(){
        echo 'hakkimizda';
    }
}
